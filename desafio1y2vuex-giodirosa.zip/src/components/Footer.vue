<template>
  <div>
    <footer>
      <h1 class="titleFooter">Sistema de compra de Video Juegos</h1>
    </footer>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
footer {
  width: 100%;
  height: 200px;
  background: #393b44;
  display: flex;
  justify-content: center;
  align-items: center;
  .titleFooter {
    font-size: 20px;
    font-weight: 300;
    color: darkgray;
  }
}
</style>
